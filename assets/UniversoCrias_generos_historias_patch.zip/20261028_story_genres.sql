-- Universo dos Crias: gêneros das histórias
-- Idempotente. Execute no SQL Editor do projeto Supabase usado pelo site.
BEGIN;

ALTER TABLE public.stories
    ADD COLUMN IF NOT EXISTS genres text[] NOT NULL DEFAULT ARRAY[]::text[];

UPDATE public.stories
SET genres = ARRAY[]::text[]
WHERE genres IS NULL;

ALTER TABLE public.stories
    ALTER COLUMN genres SET DEFAULT ARRAY[]::text[];

ALTER TABLE public.stories
    ALTER COLUMN genres SET NOT NULL;

COMMENT ON COLUMN public.stories.genres IS
    'Lista de gêneros selecionados pelo escritor para exibição na página pública da história.';

COMMIT;
