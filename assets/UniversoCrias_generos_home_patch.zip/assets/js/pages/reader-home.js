import { setupTheme } from "../core/theme.js?v=20261028-crias-presence-images-2";
import { setupProfanityFilter } from "../core/profanity-filter.js?v=20261028-crias-presence-images-2";
import { normalizeStoryGenres } from "../core/story-genres.js?v=20261028-story-genres-home-1";
import {
    escapeHtml,
    ratingStars,
    storyCoverSource,
} from "../core/utils.js";
import { getPublishedStories } from "../services/story.service.js?v=20261027-coauthor-2";
import { getStoryAuthors } from "../core/story-authors.js?v=20261027-coauthor-2";
import { getStoryCoverUrl } from "../services/storage.service.js";
import { getPublishedStoryRatingSummaries } from "../services/review.service.js";
import { initCriasPresence } from "../services/crias-presence.service.js?v=20261028-crias-presence-images-2";

setupTheme();
setupProfanityFilter();

const criasPresence = initCriasPresence({
    details: "Navegando pelas histórias",
    state: "Universo dos Crias",
});

const grid =
    document.querySelector("#story-grid");

const count =
    document.querySelector("#story-count");

const searchInput =
    document.querySelector("#story-search");

const searchStatus =
    document.querySelector("#story-search-status");

const writerFilter =
    document.querySelector("[data-writer-filter]");

const writerFilterToggle =
    document.querySelector("#writer-filter-toggle");

const writerFilterMenu =
    document.querySelector("#writer-filter-menu");

let allStories = [];
let storyRatingSummaries = {};
let selectedWriter = "all";
let renderSequence = 0;

function normalizeSearchText(value) {
    return String(value ?? "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLocaleLowerCase("pt-BR")
        .trim();
}

function getAuthorEntries(story) {
    return getStoryAuthors(story);
}

function getAuthorLabel(story) {
    return getAuthorEntries(story)
        .map((author) => author.name)
        .join(", ") || "Autor não informado";
}

function renderStoryGenresLine(story) {
    const genres = normalizeStoryGenres(story?.genres);
    if (!genres.length) return "";

    return `
        <p class="story-card-genres">
            <strong>Gêneros:</strong> ${escapeHtml(genres.join(", "))}
        </p>
    `;
}

async function storyCard(story) {
    const cover =
        await storyCoverSource(
            story,
            getStoryCoverUrl,
        );

    const publishedCount =
        (story.seasons ?? []).reduce(
            (sum, season) =>
                sum +
                (season.chapters ?? []).length,
            0,
        );

    const authorLabel =
        getAuthorLabel(story);

    const ratingSummary =
        storyRatingSummaries[String(story.id)] || {
            average: 0,
            count: 0,
        };

    return `
        <a
            class="story-card"
            href="./historia.html?slug=${encodeURIComponent(story.slug)}"
        >
            <img
                class="story-cover"
                src="${escapeHtml(cover)}"
                alt="Capa de ${escapeHtml(story.title)}"
            >

            <div class="story-card-body">
                <span class="eyebrow">OBRA</span>
                <h3>${escapeHtml(story.title)}</h3>

                <p class="story-author">
                    ${getAuthorEntries(story).length > 1 ? "Autores:" : "por"}
                    ${escapeHtml(authorLabel)}
                </p>

                <p>
                    ${escapeHtml(
                        story.description ||
                        "Sem descrição disponível."
                    )}
                </p>

                ${renderStoryGenresLine(story)}

                <div class="rating-line">
                    <span title="${ratingSummary.count} avaliações">
                        ${ratingStars(ratingSummary.average)}
                    </span>
                    <strong class="rating-score">
                        ${ratingSummary.count ? `${ratingSummary.average.toFixed(1)}/10` : "Sem notas"}
                    </strong>
                    <span class="muted">
                        ${publishedCount}
                        ${
                            publishedCount === 1
                                ? "episódio publicado"
                                : "episódios publicados"
                        }
                    </span>
                </div>
            </div>
        </a>
    `;
}

function storyCardFallback(story) {
    const publishedCount = (story.seasons ?? []).reduce(
        (sum, season) => sum + (season.chapters ?? []).length,
        0,
    );
    const authorLabel = getAuthorLabel(story);
    const authorCount = getAuthorEntries(story).length;
    const summary = storyRatingSummaries[String(story.id)] || { average: 0, count: 0 };
    const defaultCover = "./assets/img/default-story-cover.svg";
    return `
        <a class="story-card" href="./historia.html?slug=${encodeURIComponent(story.slug)}">
            <img class="story-cover" src="${defaultCover}" alt="Capa de ${escapeHtml(story.title)}">
            <div class="story-card-body">
                <span class="eyebrow">OBRA</span>
                <h3>${escapeHtml(story.title)}</h3>
                <p class="story-author">${authorCount > 1 ? "Autores:" : "por"} ${escapeHtml(authorLabel)}</p>
                <p>${escapeHtml(story.description || "Sem descrição disponível.")}</p>
                ${renderStoryGenresLine(story)}
                <div class="rating-line">
                    <span title="${summary.count} avaliações">${ratingStars(summary.average)}</span>
                    <strong class="rating-score">${summary.count ? `${summary.average.toFixed(1)}/10` : "Sem notas"}</strong>
                    <span class="muted">${publishedCount} ${publishedCount === 1 ? "episódio publicado" : "episódios publicados"}</span>
                </div>
            </div>
        </a>
    `;
}

function updateCount(stories) {
    count.textContent =
        `${stories.length} ${
            stories.length === 1
                ? "obra"
                : "obras"
        }`;
}

async function renderStories(stories, context = {}) {
    const renderId = ++renderSequence;
    updateCount(stories);

    if (!stories.length) {
        const cleanSearch =
            String(context.searchTerm ?? "").trim();
        const hasWriterFilter =
            selectedWriter !== "all";

        let message = "Ainda não existem histórias.";

        if (cleanSearch && hasWriterFilter) {
            message = "Nenhuma história encontrada com esses filtros.";
        } else if (cleanSearch) {
            message = "Nenhuma história encontrada.";
        } else if (hasWriterFilter) {
            message = "Esse escritor ainda não possui histórias publicadas.";
        }

        grid.innerHTML = `
            <article class="empty-card search-empty-card">
                <span class="eyebrow">${
                    cleanSearch || hasWriterFilter
                        ? "FILTRO"
                        : "BIBLIOTECA"
                }</span>
                <h3>${escapeHtml(message)}</h3>
                <p class="muted">
                    ${
                        cleanSearch
                            ? `Busca: <strong>${escapeHtml(cleanSearch)}</strong>.`
                            : "Tente selecionar outro escritor ou limpar o filtro."
                    }
                </p>
            </article>
        `;
        return;
    }

    try {
        const cards = await Promise.all(stories.map(storyCard));
        if (renderId !== renderSequence) return;
        grid.innerHTML = cards.join("");
    } catch (error) {
        console.error("Não foi possível preparar as capas das histórias.", error);
        if (renderId !== renderSequence) return;
        grid.innerHTML = stories.map((story) => storyCardFallback(story)).join("");
    }
}

function getWriterOptions() {
    const writers = new Map();

    allStories.forEach((story) => {
        getAuthorEntries(story).forEach((author) => {
            const key = String(author.id ?? author.username ?? "");
            if (!key || writers.has(key)) {
                return;
            }

            writers.set(key, {
                key,
                name: author.name,
                username: author.username || "",
            });
        });
    });

    return Array.from(writers.values())
        .sort((a, b) =>
            a.name.localeCompare(
                b.name,
                "pt-BR",
                { sensitivity: "base" },
            )
        );
}

function renderWriterFilterMenu() {
    if (!writerFilterMenu) {
        return;
    }

    const writers = getWriterOptions();

    writerFilterMenu.innerHTML = `
        <button
            class="writer-filter-option ${
                selectedWriter === "all" ? "active" : ""
            }"
            type="button"
            role="menuitem"
            data-writer-value="all"
        >
            <span>Todos os escritores</span>
            <span class="writer-filter-count">${allStories.length}</span>
        </button>

        ${writers.map((writer) => {
            const storyCount = allStories.filter(
                (story) => getAuthorEntries(story).some(
                    (author) => String(author.id ?? author.username ?? "") === writer.key
                )
            ).length;

            return `
                <button
                    class="writer-filter-option ${
                        selectedWriter === writer.key ? "active" : ""
                    }"
                    type="button"
                    role="menuitem"
                    data-writer-value="${escapeHtml(writer.key)}"
                >
                    <span>
                        ${escapeHtml(writer.name)}
                        ${
                            writer.username
                                ? `<small>@${escapeHtml(writer.username)}</small>`
                                : ""
                        }
                    </span>
                    <span class="writer-filter-count">${storyCount}</span>
                </button>
            `;
        }).join("")}
    `;

    writerFilterMenu
        .querySelectorAll("[data-writer-value]")
        .forEach((button) => {
            button.addEventListener("click", () => {
                selectedWriter =
                    button.dataset.writerValue || "all";

                updateWriterFilterLabel(writers);
                closeWriterMenu();
                applyFilters();
            });
        });
}

function updateWriterFilterLabel(writers = getWriterOptions()) {
    if (!writerFilterToggle) {
        return;
    }

    if (selectedWriter === "all") {
        writerFilterToggle.textContent =
            "Escritor: todos";
        return;
    }

    const selected = writers.find(
        (writer) => writer.key === selectedWriter
    );

    writerFilterToggle.textContent =
        selected
            ? `Escritor: ${selected.name}`
            : "Escritor: todos";
}

function openWriterMenu() {
    if (!writerFilterMenu || !writerFilterToggle) {
        return;
    }

    writerFilterMenu.hidden = false;
    writerFilterToggle.setAttribute(
        "aria-expanded",
        "true",
    );
}

function closeWriterMenu() {
    if (!writerFilterMenu || !writerFilterToggle) {
        return;
    }

    writerFilterMenu.hidden = true;
    writerFilterToggle.setAttribute(
        "aria-expanded",
        "false",
    );
}

function applyFilters() {
    const searchTerm =
        normalizeSearchText(
            searchInput?.value,
        );

    const filteredStories =
        allStories.filter((story) => {
            const title =
                normalizeSearchText(
                    story.title,
                );

            const authors = getAuthorEntries(story);
            const matchesAuthorSearch = authors.some((author) =>
                normalizeSearchText(author.name).includes(searchTerm) ||
                normalizeSearchText(author.username).includes(searchTerm)
            );

            const matchesSearch =
                !searchTerm ||
                title.includes(searchTerm) ||
                matchesAuthorSearch;

            const matchesWriter =
                selectedWriter === "all" ||
                authors.some((author) =>
                    String(author.id ?? author.username ?? "") === selectedWriter
                );

            return (
                matchesSearch &&
                matchesWriter
            );
        });

    if (searchStatus) {
        const filtersApplied =
            Boolean(searchTerm) ||
            selectedWriter !== "all";

        searchStatus.textContent =
            filtersApplied
                ? `${filteredStories.length} ${
                    filteredStories.length === 1
                        ? "resultado"
                        : "resultados"
                }`
                : "";
    }

    renderStories(
        filteredStories,
        { searchTerm },
    );
}

async function load() {
    try {
        allStories =
            await getPublishedStories();

        try {
            storyRatingSummaries =
                await getPublishedStoryRatingSummaries(
                    allStories.map((story) => story.id),
                );
        } catch (ratingError) {
            console.warn("Não foi possível carregar as médias das obras.", ratingError);
            storyRatingSummaries = {};
        }

        renderWriterFilterMenu();
        updateWriterFilterLabel();
        renderStories(allStories);
    } catch (error) {
        console.error(error);

        count.textContent = "—";
        grid.innerHTML = `
            <article class="error-card">
                Não foi possível carregar as histórias.
            </article>
        `;
    }
}

writerFilterToggle?.addEventListener(
    "click",
    () => {
        const shouldOpen =
            writerFilterMenu?.hidden ?? true;

        if (shouldOpen) {
            openWriterMenu();
        } else {
            closeWriterMenu();
        }
    },
);

document.addEventListener(
    "click",
    (event) => {
        if (
            writerFilter &&
            !writerFilter.contains(event.target)
        ) {
            closeWriterMenu();
        }
    },
);

document.addEventListener(
    "keydown",
    (event) => {
        if (event.key === "Escape") {
            closeWriterMenu();
        }
    },
);

searchInput?.addEventListener(
    "input",
    applyFilters,
);

load();
